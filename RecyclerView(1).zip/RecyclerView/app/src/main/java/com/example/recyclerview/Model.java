package com.example.recyclerview;

public class Model {

    private String titleTV,descriptionTV,locationTV,jobTV,stipentTV,educationTV;
    private int img;

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }

    public String getTitleTV() {
        return titleTV;
    }

    public void setTitleTV(String titleTV) {
        this.titleTV = titleTV;
    }

    public String getDescriptionTV() {
        return descriptionTV;
    }

    public void setDescriptionTV(String descriptionTV) {
        this.descriptionTV = descriptionTV;
    }

    public String getLocationTV() {
        return locationTV;
    }

    public void setLocationTV(String locationTV) {
        this.locationTV = locationTV;
    }

    public String getJobTV() {
        return jobTV;
    }

    public void setJobTV(String jobTV) {
        this.jobTV = jobTV;
    }

    public String getStipentTV() {
        return stipentTV;
    }

    public void setStipentTV(String stipentTV) {
        this.stipentTV = stipentTV;
    }

    public String getEducationTV() {
        return educationTV;
    }

    public void setEducationTV(String educationTV) {
        this.educationTV = educationTV;
    }
}